// +build !constrained

package config

func foo() {
	println("foo")
}
