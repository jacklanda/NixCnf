# CHANGELOG

- Impl logging feature and fix some auto update disorders. #319
- Change `t:vista` to `g:vista` as `t:vista` causes too many issues and I don't have time to make it work as initially designed. #269
