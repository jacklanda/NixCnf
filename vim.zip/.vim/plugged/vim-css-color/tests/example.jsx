var Example = React.createClass({
	render: function() {
		var style = {
			color: '#ffde00',
			backgroundColor: 'green',
			border: '3px dotted rgba(255,0,0)'
			fontSize: 200
		};
		return <div style={style}> Hi! </div>;
	}
});
