# vim-sqlfmt

![SQLFmt is SQL formatter](https://raw.githubusercontent.com/mattn/vim-sqlfmt/master/screenshot.gif)

    :SQLFmt

vim plugin for SQL code format. similar to `:GoFmt`.

## Installation

This plugin require andialbrecht's sqlformat command

```
$ pip install --upgrade sqlparse
```

## Author

Yasuhiro Matsumoto (a.k.a. mattn)
