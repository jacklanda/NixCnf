# Testing

### Running unit tests only
```
echo "" > vim_debug.log && vim -s unit_tests_only.vim -V0vim_debug.log -u test_vimrc && cat vim_debug.log
```
