# vim-cursorword
## Underlines the word under the cursor
![vim-cursorword](https://raw.githubusercontent.com/wiki/itchyny/vim-cursorword/image/image.gif)

## Installation
Install with your favorite plugin manager.

## Author
itchyny (https://github.com/itchyny)

## License
This software is released under the MIT License, see LICENSE.
